#define MAX_PATH                128
#define MAX_STRING              128

#define DEFAULT_POINTSIZE       40
#define DEFAULT_HRES            96
#define DEFAULT_VRES            96
#define DEFAULT_ELEMSIZE        4.0
#define DEFAULT_POVNAME         "text.pov"
#define DEFAULT_INCNAME         "text.inc"
