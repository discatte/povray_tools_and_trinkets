/**************************************************************************/
/*                                                                        */
/*  softtext -- a utility to make soft text out of any Truetype font.     */
/*              This program produces output in POV-Ray format as a blob  */
/*              made of spheres.                                          */
/*                                                                        */
/*  Version 0.9                                                           */
/*                                                                        */
/*  Copyright (c) 1999 by Remco de Korte & Rudy Velthuis                  */
/*                                                                        */
/*  Using the Freetype library                                            */
/*  Copyright (c) 1996-1998 by D. Turner, R. Wilhelm and W. Lemberg       */
/*  http://www.freetype.org                                               */
/*                                                                        */
/**************************************************************************/

/*

    This source code is freeware. You can use it at your own will.
    However, you may not remove the copyright notice above, if you want
    to distribute a modified file. We strongly advocate the distribution
    of the complete .zip file, either in this format or in any other
    format suited to your platform.

    If you use parts of this source code, you MUST put a line of credit
    and the above copyright notice in your documentation.

    Please also read the FreeType license information.

    DISCLAIMER

    This source code is provided to you AS IS without warranty
    of any kind, either expressed or implied. The author does not
    warrant that the functions contained in this source code meet
    your requirements or work uninterrupted or error-free. In no
    event will the author be liable to you or any third party for
    any damages, including any loss of profit, lost savings or other
    incidental, consequential or special damages.

*/

/*
    Some remarks:

    - I'm not very pleased with the default 4 colour palette, used for
      antialiasing, in FreeType. Even the promised 17 color palette is not
      exactly what I like. The POV output is much too coarse, IMHO.
      If possible, I'll try to do a simple render to bitmap to a 8 times
      higher resolution and then average all pixels in an 8x8 square,
      creating my own antialiasing. After all, this is how FreeType does
      it's antialiasing too.

      By using a factor of 8, The averaging can be done bytewise, which can
      speed up code again, esp. if a 256-byte table is used, with the number
      of bits for every byte.

    - Although it's not strict ANSI, this program relies on the presence of
      the getopt() function. If you don't have this function on your
      system, I'm afraid you'll have to do your own command line processing.


*/

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>

#include "freetype.h"
#include "softtext.h"

TT_Engine           engine;
TT_Face             face;
TT_Instance         instance;
TT_Glyph            glyph;
TT_Glyph_Metrics    metrics;
TT_CharMap          charmap;
TT_Raster_Map       pixmap;
TT_Face_Properties  properties;

int          pointsize = DEFAULT_POINTSIZE;
int          hres = DEFAULT_HRES;
int          vres = DEFAULT_VRES;
double       elementsize = DEFAULT_ELEMSIZE;
char         povName[MAX_PATH] = DEFAULT_POVNAME;
char         incName[MAX_PATH] = DEFAULT_INCNAME;

int          verbose = 0;
char         *ttfName;
char         *textString;
TT_UShort    numGlyphs;
TT_UShort    numCodes, glyphCodes[MAX_STRING];

TT_F26Dot6   xMin, yMin, xMax, yMax;
TT_F26Dot6   x, y, z;

/*
 *  Usage -- print command line options and exit program
 */
static void Usage()
{
  fprintf(
    stderr,
    "Usage: softtext [options] ttffile textstring\n"
    "  Options:\n"
    "  -p  point size            (default 40)\n"
    "  -r  overall resolution    (default 96)\n"
    "  -x  horizontal resolution (default 96)\n"
    "  -y  vertical resolution   (default 96)\n"
    "  -e  blob element size     (default 0.5)\n"
    "  -o  POV output file name  (default text.pov)\n"
    "  -i  INC output file name  (default text.inc)\n"
    "Example: sofftext -p36 -e5.0 -isoft.inc arial.ttf \"Soft Text\"\n"
  );
  exit(1);
}


/*
 *  Error -- display error message using a format string, and exit program
 *
 *    message   format string for error message
 *    ...       optional extra parameters for format string
 */
static void Error(char *message, ...)
{
  va_list args;

  fprintf(stderr, "Error: ");
  va_start(args, message);
  vfprintf(stderr, message, args);
  va_end(args);
  fprintf(stderr, "\n");
  exit(1);
}


/*
 *  FTTry -- check a FreeType return value and either display an error
 *           message using a format string or return true.
 *
 *    error     FreeType call return value
 *    message   error message format string
 *    ...       optional extra parameters for format string
 *
 *  Typical use: FTTry(FreeTypeFunc(params), "Error message %s", params);
 */
static TT_Error FTTry(TT_Error error, char *message, ...)
{
  va_list args;

  if (!error)
    return !error;
  fprintf(stderr, "FreeType error 0x%04X: ", (unsigned int)error);
  va_start(args, message);
  vfprintf(stderr, message, args);
  va_end(args);
  fprintf(stderr, "\n");
  exit(1);
}

/*
 *  WritePov -- write the output POV file
 */
static void WritePov(void)
{
  FILE *pov;

  pov = fopen(povName, "w");
  if (!pov)
    Error("Couldn't create POV file \"%s\"", povName);

  fprintf(pov, "// This POV scene file was created by softtext\n"
               "// Copyright(c) 1999 by Remco de Korte & Rudy Velthuis\n"
               "\n"
               "#include \"%s\"\n"
               "\n"
               "camera {\n"
               "  location <0.0, 0.0, -500.0>\n"
               "  look_at  <0.0, 0.0,    0.0>\n"
               "  angle    60.0\n"
               "}\n"
               "\n"
               "sky_sphere {\n"
               "  pigment {\n"
               "    gradient y\n"
               "    color_map {\n"
               "      [0 rgb <0.20, 0.15, 0.50>]\n"
               "      [1 rgb <0.60, 0.70, 0.80>]\n"
               "    }\n"
               "  }\n"
               "}\n"
               "\n"
               "light_source { <-100.0, 100.0, -50.0> rgb <1.0, 1.0, 1.0> }\n"
               "light_source { < 100.0,  50.0, -50.0> rgb <0.7, 0.7, 0.7> shadowless }\n"
               "light_source { < 100.0, 200.0,  20.0> rgb <0.4, 0.4, 0.4> shadowless }\n"
               "light_source { <   0.0, 100.0,  50.0> rgb <0.1, 0.1, 0.1> shadowless }\n"
               "\n"
               "object { softtext }\n",
               incName);
  fclose(pov);
}

static void WriteInc(TT_Raster_Map *pixmap)
{
  FILE *inc;
  TT_Byte *p, b;
  int x, y, width, rows, cols, hwidth, hrows;

  inc = fopen(incName, "w");
  if (!inc)
    Error("Couldn't create INC file \"%s\"", incName);

  /* Produces ugly format (no indentation, etc), but saves disk space
     and memory, because file can become very large).
  */

  cols = pixmap->cols;
  width = pixmap->width;
  rows = pixmap->rows;
  hwidth = width / 2;
  hrows = rows / 2;
  p = pixmap->bitmap;
  if (width <= 0 || rows <= 0 || cols <= 0 || !p)
    Error("Invalid pixel map - shouldn't happen");

  fprintf(inc, "// This blob has the following size:\n"
               "// left: %d, right: %d, top: %d, bottom: %d\n",
               -hwidth, -hwidth + width, -hrows + rows, -hrows);

  fprintf(inc, "#declare softtext=blob{threshold .7\n");

  for (y = 0; y < rows; y++)
    for (x = 0; x < width; x++)
    {
      b = p[x + y * cols];
      if (b)
        fprintf(inc, "sphere{<%d,%d,0>,%.2f,%.2f}\n",
                x - hwidth, y - hrows, elementsize, 0.64 * b);
    }

  fprintf(inc, "pigment{rgb<1,0,0>}}\n");
  fclose(inc);
}

int main(int argc, char **argv)
{
  extern int optind;    /* option index for getopt() */
  extern char *optarg;  /* option argument for getopt() */

  int c;
  unsigned short n, i;
  unsigned short encoding, platform;
  int first;
  int xoffset, yoffset;
  TT_Byte *p;

  FILE *f;

  /* Copyright notice */

  printf("\n"
         "softtext -- Create soft blob text for POV-Ray\n"
         "Version 0.9, Copyright (c) 1999 Remco de Korte & Rudy Velthuis\n"
         "\n");

  /* Evaluate command line */

  while ((c = getopt(argc, argv, "p:r:x:y:ve:")) != -1)
  {
    switch ((char)c)
    {
      case 'p':
        pointsize = atof(optarg);
        break;
      case 'r':
        hres = vres = atof(optarg);
        break;
      case 'x':
        hres = atof(optarg);
        break;
      case 'y':
        vres = atof(optarg);
        break;
      case 'e':
        elementsize = atof(optarg);
        break;
      case 'o':
        strncpy(povName, optarg, 255);
        break;
      case 'i':
        strncpy(incName, optarg, 255);
        break;
      case 'v':
        verbose = 1;
        break;
      default:
        Usage();
    }
  }

  if (argc - optind != 2)
    Usage();

  ttfName = argv[optind];
  textString = argv[optind + 1];

  /* Initialise FreeType structures */

  FTTry(TT_Init_FreeType(&engine), "Couldn't initialise engine");

  FTTry(TT_Open_Face(engine, ttfName, &face),
        "Couldn't open TrueType file \"%s\"", ttfName);

  FTTry(TT_Get_Face_Properties(face, &properties),
        "Couldn't get type face properties");

  numGlyphs = properties.num_Glyphs;

  FTTry(TT_New_Glyph(face, &glyph),
        "Couldn't create glyph container");

  FTTry(TT_New_Instance(face, &instance),
        "Couldn't create instance for %s", ttfName);

  FTTry(TT_Set_Instance_Resolutions(instance, hres, vres),
        "Couldn't set type face resolution %d x %d", hres, vres);

  FTTry(TT_Set_Instance_CharSize(instance, (TT_F26Dot6)(pointsize * 64.0)),
        "Couldn't set point size %d", pointsize);

  /* Get a suitable character map */
  /* Which character map is suitable might depend on your needs and
     your system. I'm not an expert in this, so if necessary, change
     the code in the following lines accordingly. */

  n = properties.num_CharMaps;

  for (i = 0; i < n; i++)
  {

    FTTry(TT_Get_CharMap_ID(face, i, &platform, &encoding),
          "Couldn't get character map ID %d", i);

    /* Unicode: only for Windows and Mac. */
    /* Change this for your platform, if necessary. */
    if ((platform == 0 && encoding == 0) ||
        (platform == 3 && encoding == 1))
    {
      FTTry(TT_Get_CharMap(face, i, &charmap),
            "Couldn't get character map %d", i);
      i = n + 1;
    }
  }

  if (i == n)
    Error("Couldn't find suitable character map in \"%s\"", ttfName);

  /* Find the glyph codes and metrics, calculating the size of the
     bitmap. */

  x = y = 0;
  xMin = xMax = yMin = yMax = 0;

  first = 1;

  /* Get the glyph codes for the textstring and in the mean time
     calculate the size of the bitmap needed */
  for (i = 0; i < MAX_STRING && textString[i]; i++)
  {

    /* My own simple code conversion, not real Unicode! */
    glyphCodes[i] = TT_Char_Index(charmap,
                                  ((short)textString[i] < numGlyphs) ?
                                    (short)textString[i] : (short)' ');

    FTTry(TT_Load_Glyph(instance, glyph, glyphCodes[i], TTLOAD_DEFAULT),
          "Couldn't load glyph %d", i);

    FTTry(TT_Get_Glyph_Metrics(glyph, &metrics),
          "Couldn't get glyph metrics for glyph %d", i);

    if (first)
    {
      xMin = metrics.bbox.xMin;
      first = 0;
    }
    xMax = x * 64 + metrics.bbox.xMax;

    if (metrics.bbox.yMin < yMin)
      yMin = metrics.bbox.yMin;

    if (metrics.bbox.yMax > yMax)
      yMax = metrics.bbox.yMax;

    x += (metrics.advance + 32) / 64;
  }

  numCodes = i;

  /* Setup bitmap values and allocate bitmap memory. */

  xoffset = -(xMin - 63) / 64;
  yoffset = -(yMin - 63) / 64;

  pixmap.width = (xMax + 63) / 64 + xoffset;
  pixmap.cols = (pixmap.width + 3) & -4; /* for pixmaps! */
  pixmap.rows = (yMax + 63) / 64 + yoffset;
  pixmap.flow = TT_Flow_Up;
  pixmap.size = (long)pixmap.cols * pixmap.rows;
  if ((pixmap.bitmap = malloc(pixmap.size)) == NULL)
    Error("Couldn't allocate bitmap of size %ld", pixmap.size);
  memset(pixmap.bitmap, 0, pixmap.size);

  /* Print some info if verbose is on. */

  if (verbose)
  {
    printf("ttfName    = \"%s\"\ntextString = \"%s\"\n\n",
           ttfName, textString);
    printf("pointsize  = %8d\nhres       = %8d\nvres       = %8d\n\n",
           pointsize, hres, vres);
    printf("width      = %8d\ncols       = %8d\n"
           "rows       = %8d\nsize       = %8ld\n",
           pixmap.width, pixmap.cols, pixmap.rows, pixmap.size);
    printf("xoffset    = %8d\nyoffset    = %8d\n",
           xoffset, yoffset);
  }

  /* Now render the individual glyphs to the pixmap. */

  for (i = 0, x = xoffset; i < numCodes; i++)
  {
    FTTry(TT_Load_Glyph(instance, glyph, glyphCodes[i], TTLOAD_DEFAULT),
          "Couldn't load glyph %d", glyphCodes[i]);
    FTTry(TT_Get_Glyph_Metrics(glyph, &metrics),
          "Couldn't get metrics for glyph %d", glyphCodes[i]);

    FTTry(TT_Get_Glyph_Pixmap(glyph, &pixmap, x * 64, yoffset * 64),
          "Couldn't render glyph %d", glyphCodes[i]);
    x += (metrics.advance + 32) / 64;
  }


  /* for testing only ---------------------------------------------------*/

  /* could make this a tga file */
  f = fopen("test.pmp", "wb");
  fwrite(&pixmap.cols, sizeof(pixmap.cols), 1, f);
  fwrite(&pixmap.rows, sizeof(pixmap.rows), 1, f);
  fwrite(pixmap.bitmap, sizeof(TT_Byte), pixmap.size, f);
  fclose(f);

  /* writes a simple text file */
  f = fopen("test.txt", "w");
  n = (pixmap.rows > 79) ? 79 : pixmap.rows;
  p = (TT_Byte *)pixmap.bitmap;
  for (y = pixmap.rows - 1; y >= 0; y--)
  {
    for (x = 0; x < pixmap.width; x++)
    switch (p[x + pixmap.cols*y])
    {
      case 0: fprintf(f, "."); break;
      case 1: fprintf(f, ":"); break;
      case 2: fprintf(f, "+"); break;
      case 3: fprintf(f, "*"); break;
      case 4: fprintf(f, "#"); break;
    }
    fprintf(f, "\n");
  }
  fclose(f);

  /*---------------------------------------------------------------------*/


  TT_Done_FreeType(engine);

  WritePov();
  WriteInc(&pixmap);

  return 0;
}


